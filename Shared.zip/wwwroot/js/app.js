﻿var saveMessage = function (Name, Email) {
    // alert("Record inserted successfully. Name is : " + Name + " and email id : " + Email);
    document.getElementById("message").innerText = "Record inserted successfully. Name is : " + Name + " and email id : " + Email;
}